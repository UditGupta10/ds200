
# coding: utf-8

# In[65]:


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


# In[66]:


df = pd.read_csv('D://CDS/Research methods//Module 4//housing_price_index.csv',header=None)
print(df)


# In[67]:


xlabel = ['06-2011', '09-2011', '12-2011', '03-2012', '06-2012','09-2012', '12-2012', '03-2013', '06-2013', '09-2013']
plt.scatter(range(1,11), df.loc[2][1:])
plt.show()


# In[68]:


plt.figure()
#box = [df[1][1:], df[2][1:], df[3][1:], df[4][1:], df[5][1:]]
box=[]
box.append(df[1][1:].values.astype(float))
box.append(df[2][1:].values.astype(float))
box.append(df[3][1:].values.astype(float))
plt.boxplot(box)
plt.show()


# In[69]:


(df[1][1:].values.astype(float))


# In[70]:


plt.figure()
plt.plot(df[1][1:])
#plt.hold(True)
plt.plot(df[2][1:])
plt.plot(df[3][1:])
plt.show()

